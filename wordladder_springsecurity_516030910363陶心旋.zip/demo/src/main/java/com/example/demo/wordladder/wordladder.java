package com.example.demo.wordladder;

import java.util.*;
import java.io.File;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.FileInputStream;
import javax.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/txx")

public class wordladder {
	Map<String, String>auth = new HashMap<String, String>();
	public static String wladder(Set<String> wordlist1,Set<String> wordlist2,String word1,String word2) {
		boolean done = false;
		Stack<String>orig = new Stack<>();
		Stack<String>ans = new Stack<>();
		Queue<Stack<String>>ladder = new LinkedList<Stack<String>>();
		wordlist2.remove(word1);
		orig.push(word1);
		ladder.add(orig);
		while (ladder.size()!= 0 && !done) {
			Stack<String>start = ladder.poll();
			int length = word1.length();
			for (int pos = 0;pos< length;pos++) {
				String word_orig = start.peek();
				char []chs = word_orig.toCharArray();
				for (char j = 'a';j <= 'z'; j++) {
					chs[pos] =  j;
					String word_temp = new String(chs);
					if (wordlist1.contains(word_temp) && !word_temp.equals(word_orig) && done != true) {
						if (wordlist2.contains(word_temp)) {
							if(word_temp.equals(word2)) {
								done = true;
								start.push(word2);
								ans = start;
							}
							else {
								wordlist2.remove(word_temp);
								Stack<String>stack_temp = new Stack<>();
								for (String s:start) {
									stack_temp.push(s);
								}
								stack_temp.push(word_temp);
								ladder.add(stack_temp);
							}
						}
					}
					if (done) break;
				}
				if (done) break;
			}
		}
		if (done)
		{
			System.out.print("The ladder from " + word1 + " back to " + word2 + ":\n");
			String result = "";
			while (!ans.empty()) {
				result += ans.pop();
				result += " ";
			}
			return "The ladder from " + word1 + " back to " + word2 + ":\n" + result ;
		}
		if (!done) {
			System.out.print("No word ladder found from" + word1 + "back to" + word2 + ".\n");
			return "No word ladder found from" + word1 + "back to" + word2 + ".\n";
		}
		return "null";
}
	public static Set<String> file(String pathname) {
		Set<String>wordlist = new HashSet<>();
		try {
			File infile = new File(pathname);
			InputStreamReader reader = new InputStreamReader(new FileInputStream(infile));
			BufferedReader br = new BufferedReader(reader);
			String line = "";
			line = br.readLine();
			wordlist.add(line);
			while ((line = br.readLine()) != null) {
				wordlist.add(line);
			}
			return wordlist;
		} catch (Exception e) {
			e.printStackTrace();
			return wordlist;
		}
	}
	@RequestMapping("/wl")
	public String main(HttpServletRequest request) {
		Set<String> set1 = file("src/main/dictionary.txt");
		Set<String> set2 = file("src/main/dictionary.txt");
		
		String startword = request.getParameter("start");
        String endword = request.getParameter("end");
       /* String login = request.getParameter("login");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        if (login.equals("r")) {
        	auth.put(username, password);
        	return "注册成功！";
        }
        else if (login.equals("l")) {
        	if (auth.containsKey(username)) {
        		String pswd = auth.get(username);
        		if (pswd.equals(password)) {
        			return wladder(set1,set2,startword,endword);
        		}
        		return "密码错误";	
        	}
        	return "登录失败";
        }
        return "404 NOT FOUND.";
        */
        return wladder(set1,set2,startword,endword);
	}


}